package com.fm.financemanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanceManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
